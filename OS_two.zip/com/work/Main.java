package com.work;


public class Main {

    public static void main(String[] args) {
        Simulation simulation=new Simulation();
        simulation.execute();
    }
}
