package com.work;

import java.util.LinkedList;
import java.util.Scanner;

public  class Simulation {
    private LinkedList<TableBean> list = new LinkedList<>();
    private int[] p = {0, 1, 2, 3};
    private int k = 0;

    public Simulation() {
        list.add(new TableBean(0, 1, "5", 0, 11));
        list.add(new TableBean(1, 1, "8", 0, 12));
        list.add(new TableBean(2, 1, "9", 0, 13));
        list.add(new TableBean(3, 1, "1", 0, 21));
        list.add(new TableBean(4, 0, " ", 0, 22));
        list.add(new TableBean(5, 0, " ", 0, 23));
        list.add(new TableBean(6, 0, " ", 0, 121));
        System.out.println("------>>页表信息:");
        for (TableBean table : list) {
            System.out.println(table);
        }
        print();
    }

    public void readPage(int page, int unitNum) {
        for (TableBean table : list) {
            if (table.getPage() == page && table.getFlag() == 1) {
                //绝对地址的转换
                int absoluteAddress = Integer.parseInt(table.getBlock()) * 128 + unitNum;
                System.out.println("------>>" + page + "号页命中，该页绝对地址：" + absoluteAddress);
                //判断是否是存指令
                Scanner in = new Scanner(System.in);
                System.out.print("是否是存指令(Y/N)");
                String instruct = in.next();
                if (instruct.equals("y") || instruct.equals("Y")) {
                    table.setAlterFlag(1);
                    System.out.println("------>>将" + table.getPage() + "页的修改标志置为1");
                }
                print();
                return;
            }
        }
        System.out.println("**** " + page + "号页发生缺页中断！");
        First_In_First_Out(page);
    }

    //执行地址转换模拟算法
    public void execute() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.print("请输入页号");
            int page = in.nextInt();
            if (page == -1) {
                System.out.println("********程序执行结束********");
                return;
            }else if(page>6||page<0){
                System.out.println("******该页号不存在，请您重新输入*******");
                continue;
            }
            System.out.print("请输入单元号");
            int unitNum = in.nextInt();
            readPage(page, unitNum);
        }
    }

    //缺页中断执行FIFO页面调度
    public void First_In_First_Out(int page) {
        //修改页表
        String block = " ";
        for (TableBean table : list) {
            if (table.getPage() == p[k]) {
                //在页表中修改需要调出主存的页
                block = table.getBlock();
                table.setBlock(" ");
                table.setFlag(0);
                if (table.getAlterFlag() == 1) {
                    System.out.println("---->>"+table.getPage()+"页修改过，先调出页号回磁盘：");
                    System.out.println("---->>装入新页号：" + page);
                } else {
                    System.out.println("---->>该页未修改，直接装入新页号：" + page);
                    System.out.println("---->>被置换的旧页号为：" + table.getPage());
                }

                break;
            }
        }
        //将调入主存的页的信息填入页表
        for (TableBean table : list) {
            if (table.getPage() == page) {
                table.setFlag(1);
                table.setBlock(block);
                table.setAlterFlag(0);
            }
        }
        p[k] = page;
        k = (k + 1) % p.length;
        print();

        System.out.println("------>>页表信息");
        for (TableBean table : list) {
            System.out.println(table);
        }
    }

    public void print() {
        switch (k) {
            case 0:
                System.out.println("                  ↓");
                break;
            case 1:
                System.out.println("                    ↓");
                break;
            case 2:
                System.out.println("                      ↓");
                break;
            case 3:
                System.out.println("                        ↓");
                break;
        }
        System.out.print("（数组P）主存中页号：");
        for (int a : p) {
            System.out.print(a + " ");
        }
        System.out.println();
    }
}
