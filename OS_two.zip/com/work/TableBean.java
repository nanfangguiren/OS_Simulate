package com.work;

public class TableBean {
    private int page;//页号
    private int flag;//标志(1表示在主存）
    private String block;//主存块号
    private int alterFlag;//修改标志（1表示修改过）
    private int location;//在磁盘中的位置


    public TableBean(int page, int flag, String block, int alterFlag, int location) {
        this.page = page;
        this.flag = flag;
        this.block = block;
        this.alterFlag = alterFlag;
        this.location = location;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public int getAlterFlag() {
        return alterFlag;
    }

    public void setAlterFlag(int alterFlag) {
        this.alterFlag = alterFlag;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "页号：" + page +
                "   标志位：" + flag +
                "   主存块号：" + block +
                "   修改标志位：" +alterFlag +
                "   在磁盘中的位置：" + location ;
    }
}
